﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        /// <summary>
        /// Creating the field of IClientServices and injecting in ClientController constructor
        /// </summary>
        private readonly IDoctorServices _clientServices;
        public DoctorController(IDoctorServices clientServices)
        {
            _clientServices = clientServices;
        }

        /// <summary>
        /// //Action to add a new doctor by admin
        /// </summary>
        /// <param name="model"></param>
        /// <param name="doctorId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddDoctor")]
        [Authorize(Roles = "Admin")]
        public async Task<ClsDoctor> AddDoctor([FromBody] ClsDoctor model, int doctorId)
        {
            //do code here
            var result = _clientServices.AddDoctor(model);
            return await result;
        }

        /// <summary>
        /// Show/Get the list of doctors available based on the client search.
        /// Either client can pass the doctor name or the city name
        /// </summary>
        /// <param name="doctorName"></param>
        /// <param name="city"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("SearchDoctor")]
        public async Task<IEnumerable<ClsDoctor>> SearchDoctor(string doctorName, string city)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can remove the doctor details if its not required
        /// </summary>
        /// <param name="doctorId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("RemoveDoctor")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> RemoveDoctor(int doctorId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can edit the doctor details of an existing record
        /// </summary>
        /// <param name="doctor"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateDoctor")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> UpdateDoctor(ClsDoctor doctor)
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
