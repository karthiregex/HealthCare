﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.Entities;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HospitalController : ControllerBase
    {
        /// <summary>
        /// Creating the field of IClientServices and injecting in ClientController constructor
        /// </summary>
        private readonly IHospitalServices _hospitalServices;
        public HospitalController(IHospitalServices hospitalServices)
        {
            _hospitalServices = hospitalServices;
        }

        /// <summary>
        /// //Action to add a new hospital by admin
        /// </summary>
        /// <param name="model"></param>
        /// <param name="hospitalId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddHospital")]
        [Authorize(Roles = "Admin")]
        public async Task<ClsHospital> AddHospital([FromBody] ClsHospital model, int hospitalId)
        {
            var result = _hospitalServices.AddHospital(model);
            return await result;
        }

        /// <summary>
        /// Show/Get the list of hospitals available based on the client search.
        /// Either client can pass the hospital name or the city name
        /// </summary>
        /// <param name="hospitalName"></param>
        /// <param name="city"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("SearchHospital")]
        public async Task<IEnumerable<ClsHospital>> SearchHospital(string hospitalName, string city)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can remove the hospital details if its not required
        /// </summary>
        /// <param name="hospitalId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("RemoveHospital")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> RemoveHospital(int hospitalId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can edit the hospital details of an existing record
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateHospital")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> UpdateHospital(ClsHospital hospital)
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
