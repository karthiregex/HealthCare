﻿using System;
using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Interfaces
{
    public interface IDoctorServices
    {
        Task<ClsDoctor> GetDoctorById(long hospitalId);
        Task<ClsDoctor> GetDoctorByName(String hospitalName);
        Task<ClsDoctor> AddDoctor(ClsDoctor doctor);
        Task<ClsDoctor> UpdateDoctor(ClsDoctor doctor);
        Task<ClsDoctor> DeleteDoctor(ClsDoctor doctor);
    }
}
