﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Services.Repository
{
    public interface IDoctorRepository
    {
        Task<IEnumerable<ClsDoctor>> GetDoctorDetails();
        Task<ClsDoctor> GetDoctorById(long hospitalId);
        Task<ClsDoctor> GetDoctorByName(String hospitalName);
        Task<ClsDoctor> AddDoctor(ClsDoctor doctor);
        Task<ClsDoctor> UpdateDoctor(ClsDoctor doctor);
        Task<ClsDoctor> DeleteDoctor(ClsDoctor doctor);
    }
}
