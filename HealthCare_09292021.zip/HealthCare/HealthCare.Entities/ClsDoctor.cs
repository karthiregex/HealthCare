﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HealthCare.Entities
{
    public class ClsDoctor
    {
        [Key]
        public int DoctorId { get; set; }
        [Required]
        [Display(Name = "FirstName")]
        public string FirstName { get; set; }
        [Required]
        [Display(Name = "LastName")]
        public string LastName { get; set; }
        [Required]
        [Display(Name = "PracticingFrom")]
        public DateTime PracticingFrom { get; set; }
        [Required]
        [Display(Name = "Specialization")]
        public string Specialization { get; set; }
        [Required]
        [Display(Name = "HospitalId")]
        public int HospitalId { get; set; }
    }
}
