﻿using System.ComponentModel.DataAnnotations;

namespace HealthCare.Entities
{
    public class ClsHospital 
    {
        [Key]
        public int HospitalId { get; set; }
        [Required]
        [Display(Name = "HospitalName")]
        public string HospitalName { get; set; }
        [Required]
        [Display(Name = "FirstConsultationFee")]
        public double FirstConsultationFee { get; set; }
        [Required]
        [Display(Name = "FollowupConsultationFee")]
        public double FollowupConsultationFee { get; set; }
        [Required]
        [Display(Name = "StreetAddress")]
        public string StreetAddress { get; set; }
        [Required]
        [Display(Name = "City")]
        public string City { get; set; }
        [Required]
        [Display(Name = "State")]
        public string State { get; set; }
        [Required]
        [Display(Name = "Country")]
        public string Country { get; set; }
        [Required]
        [Display(Name = "PinCode")]
        public long PinCode { get; set; }
    }
}
