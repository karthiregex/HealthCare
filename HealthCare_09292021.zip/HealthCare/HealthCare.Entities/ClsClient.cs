﻿using System.ComponentModel.DataAnnotations;

namespace HealthCare.Entities
{
    public class ClsClient
    {
        [Key]
        public int ClientId { get; set; }
        [Required]
        [Display(Name = "FirstName")]
        public string FirstName { get; set; }
        [Required]
        [Display(Name = "LastName")]
        public string LastName { get; set; }
        [Required]
        [Display(Name = "PhoneNumber")]
        public long PhoneNumber { get; set; }
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }
}
