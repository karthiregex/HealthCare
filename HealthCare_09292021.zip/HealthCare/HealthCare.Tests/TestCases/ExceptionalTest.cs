﻿
using HealthCare.BusinessLayer.Interfaces;
using HealthCare.BusinessLayer.Services;
using HealthCare.BusinessLayer.Services.Repository;
using Moq;
using System;
using System.Threading.Tasks;
using HealthCare.BusinessLayer.ViewModels;
using HealthCare.Entities;
using Xunit;
using Xunit.Abstractions;
using Xunit.Sdk;

namespace HealthCare.Tests.TestCases
{
    public class ExceptionalTest
    {
        /// <summary>
        /// Creating Referance Variable and Mocking repository class
        /// </summary>

        private readonly IAppointmentServices _appointmentServices;
        private readonly IClientReviewServices _clientReviewServices;
        private readonly IClientServices _clientServices;
        private readonly IDoctorServices _doctorServices;
        private readonly IHospitalServices _hospitalServices;

        public readonly Mock<IAppointmentRepository> AppointmentService = new Mock<IAppointmentRepository>();
        public readonly Mock<IClientReviewRepository> ClientReviewService = new Mock<IClientReviewRepository>();
        public readonly Mock<IClientRepository> ClientService = new Mock<IClientRepository>();
        public readonly Mock<IDoctorRepository> DoctorService = new Mock<IDoctorRepository>();
        public readonly Mock<IHospitalRepository> HospitalService = new Mock<IHospitalRepository>();
        public readonly Mock<IHospitalAdminRepository> adminservice = new Mock<IHospitalAdminRepository>();

        // private UserMaster _userMaster;
        private ClsAppointment _appointment;
        private ClsClient _client;
        private ClsClientReview _clientReview;
        private ClsDoctor _doctor;
        private ClsHospital _hospital;
        // private CreateRoleViewModel _createRoleViewModel;
        // private UserRoleViewModel _userRoleViewModel;
        // private ChangePasswordViewModel _changePasswordViewModel;
        // private EditRoleViewModel _editRoleViewModel;
        private readonly ITestOutputHelper _output;
        readonly private static string type = "Exceptional";
        public ExceptionalTest(ITestOutputHelper output)
        {
            ///// <summary>
            ///// Injecting service object into Test class constructor
            ///// </summary>
            _appointmentServices = new AppointmentServices(AppointmentService.Object);
            _clientReviewServices = new ClientReviewServices(ClientReviewService.Object);
            _clientServices = new ClientServices(ClientService.Object);
            _doctorServices = new DoctorServices(DoctorService.Object);
            _hospitalServices = new HospitalServices(HospitalService.Object);
            //_adminServices = new HospitalAdminServices(adminservice.Object);
            _output = output;
            _appointment = new ClsAppointment()
            {
                ClientId = 1234,
                HospitalId = 552,
                DoctorId = 8563,
                AppBookingChannelName = "direct",
                AppointmentDate = DateTime.Now,
                AppointmentId = 112,
                StartTime = Convert.ToDateTime("05/29/2015 5:50 PM"),
                EndTime = Convert.ToDateTime("05/29/2015 6:50 PM"),
                Status = "Open"
            };

            _client = new ClsClient()
            {
                ClientId = 1234,
                Email = "Client1234@gmail.com",
                FirstName = "TestFirstName",
                LastName = "TestLastName",
                PhoneNumber = 8807712345
            };

            _clientReview = new ClsClientReview()
            {
                DoctorId = 8563,
                ClientId = 1234,
                DoctorRating = 5,
                Id = 333,
                IsDoctorRecommended = true,
                Review = "Very good Doctor",
                ReviewDate = DateTime.Now,
                WaitTimeRating = 5
            };
            _doctor = new ClsDoctor()
            {
                DoctorId = 8563,
                FirstName = "DocFirstName",
                LastName = "DocLastName",
                HospitalId = 552,
                PracticingFrom = Convert.ToDateTime("05/29/2015"),
                Specialization = "Cardiologist"
            };
            _hospital = new ClsHospital()
            {
                HospitalId = 552,
                City = "Mumbai",
                Country = "India",
                FirstConsultationFee = 500,
                FollowupConsultationFee = 300,
                HospitalName = "New Life Hospitals",
                PinCode = 400007,
                State = "Maharashtra",
                StreetAddress = "Main Road,Malabar Hill"
            };
        }
        /// <summary>
        /// Test to validate if user pass the null object while add hospital, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Validate_InvalidHospital()
        {
            //Arrange
            bool res = false;
            _hospital = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                HospitalService.Setup(repo => repo.AddHospital(_hospital)).ReturnsAsync(_hospital = null);
                var result = await _hospitalServices.AddHospital(_hospital);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if user pass the null object while add client, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_InvlidProcessLoanTrans()
        {
            //Arrange
            bool res = false;
            _client = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientService.Setup(repo => repo.AddClient(_client)).ReturnsAsync(_client = null);
                var result = await _clientServices.AddClient(_client);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if user pass the null object while add Doctor, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_InvlidSanctionedLoanTrans()
        {
            //Arrange
            bool res = false;
            _doctor = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                DoctorService.Setup(repo => repo.AddDoctor(_doctor)).ReturnsAsync(_doctor = null);
                var result = await _doctorServices.AddDoctor(_doctor);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if user pass the null object while add Appointment, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Validate_InvalidAppointment()
        {
            //Arrange
            bool res = false;
            _appointment = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                AppointmentService.Setup(repo => repo.AddAppointment(_appointment)).ReturnsAsync(_appointment = null);
                var result = await _appointmentServices.AddAppointment(_appointment);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if user pass the null object while add ClientReview, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Validate_InvalidClientReview()
        {
            //Arrange
            bool res = false;
            _clientReview = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientReviewService.Setup(repo => repo.AddClientReview(_clientReview)).ReturnsAsync(_clientReview = null);
                var result = await _clientReviewServices.AddClientReviews(_clientReview);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
    }
}
