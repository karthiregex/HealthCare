﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HealthCare.Tests.TestCases
{
    public class GetToken
    {
        public string token { get; set; }
        public string error { get; set; }
    }
}
