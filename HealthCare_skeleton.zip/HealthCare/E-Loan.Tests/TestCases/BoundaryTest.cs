﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.BusinessLayer.Services;
using HealthCare.BusinessLayer.Services.Repository;

using Moq;
using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HealthCare.BusinessLayer.ViewModels;
using HealthCare.Entities;
using Xunit;

namespace HealthCare.Tests.TestCases
{
    public class BoundaryTest
    {
        /// <summary>
        /// Creating Referance Variable and Mocking repository class
        /// </summary>
        private readonly ILoanAdminServices _adminServices;
        private readonly IAppointmentServices _appointmentServices;
        private readonly IClientReviewServices _clientReviewServices;
        private readonly IClientServices _clientServices;
        private readonly IDoctorServices _doctorServices;
        private readonly IHospitalServices _hospitalServices;

        public readonly Mock<IAppointmentRepository> AppointmentService = new Mock<IAppointmentRepository>();
        public readonly Mock<IClientReviewRepository> ClientReviewService = new Mock<IClientReviewRepository>();
        public readonly Mock<IClientRepository> ClientService = new Mock<IClientRepository>();
        public readonly Mock<IDoctorRepository> DoctorService = new Mock<IDoctorRepository>();
        public readonly Mock<IHospitalRepository> HospitalService = new Mock<IHospitalRepository>();

        private readonly UserMaster _userMaster;
        private readonly ClsAppointment _appointment;
        private readonly ClsClient _client;
        private readonly ClsClientReview _clientReview;
        private readonly ClsDoctor _doctor;
        private readonly ClsHospital _hospital;
        private readonly CreateRoleViewModel _createRoleViewModel;
        private readonly UserRoleViewModel _userRoleViewModel;
        private readonly ChangePasswordViewModel _changePasswordViewModel;
        private readonly EditRoleViewModel _editRoleViewModel;
        private static string type = "Boundary";
        public BoundaryTest()
        {
            ///// <summary>
            ///// Injecting service object into Test class constructor
            ///// </summary>
            _appointmentServices = new AppointmentServices(AppointmentService.Object);
            _clientReviewServices = new ClientReviewServices(ClientReviewService.Object);
            _clientServices = new ClientServices(ClientService.Object);
            _doctorServices = new DoctorServices(DoctorService.Object);
            _hospitalServices = new HospitalServices(HospitalService.Object);
            _appointment = new ClsAppointment()
            {
                ClientId = 1234,
                HospitalId = 552,
                DoctorId = 8563,
                AppBookingChannelName = "direct",
                AppointmentDate = DateTime.Now,
                AppointmentId = 112,
                StartTime = Convert.ToDateTime("05/29/2015 5:50 PM"),
                EndTime = Convert.ToDateTime("05/29/2015 6:50 PM"),
                Status = "Open"
            };

            _client = new ClsClient()
            {
                ClientId = 1234,
                Email = "Client1234@gmail.com",
                FirstName = "TestFirstName",
                LastName = "TestLastName",
                PhoneNumber = 8807712345
            };

            _clientReview = new ClsClientReview()
            {
                DoctorId = 8563,
                ClientId = 1234,
                DoctorRating = 5,
                Id = 333,
                IsDoctorRecommended = true,
                Review = "Very good Doctor",
                ReviewDate = DateTime.Now,
                WaitTimeRating = 5
            };
            _doctor = new ClsDoctor()
            {
                DoctorId = 8563,
                FirstName = "DocFirstName",
                LastName = "DocLastName",
                HospitalId = 552,
                PracticingFrom = Convert.ToDateTime("05/29/2015"),
                Specialization = "Cardiologist"
            };
            _hospital = new ClsHospital()
            {
                HospitalId = 552,
                City = "Mumbai",
                Country = "India",
                FirstConsultationFee = 500,
                FollowupConsultationFee = 300,
                HospitalName = "New Life Hospitals",
                PinCode = 400007,
                State = "Maharashtra",
                StreetAddress = "Main Road,Malabar Hill"
            };
            _createRoleViewModel = new CreateRoleViewModel
            {
                RoleName = "Admin"
            };
            _userRoleViewModel = new UserRoleViewModel
            {
                UserId = "1b232594-4f44-4777-9008-480746341378",
                Email = "umakumarsingh@gmail.com"
            };
            _changePasswordViewModel = new ChangePasswordViewModel
            {
                Name = "Uma",
                Email = "umakumarsingh@iiht.com",
                Password = "Password@123",
                ConfirmPassword = "Password@123"
            };
            _editRoleViewModel = new EditRoleViewModel
            {
                Id = "7f737659-aa03-4633-ad16-4c1ac83cfe98",
                RoleName = "Admin",
            };
        }

        /// <summary>
        /// Test to validate if added client and clientId is correct or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidateClientRegistrationClientId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientService.Setup(repo => repo.AddClient(_client)).ReturnsAsync(_client);
                var result = await _clientServices.AddClient(_client);

                if (result.ClientId == _client.ClientId)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if added hospital and hospitalId is correct or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidateHospital_HospitalId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                HospitalService.Setup(repo => repo.AddHospital(_hospital)).ReturnsAsync(_hospital);
                var result = await _hospitalServices.AddHospital(_hospital);

                if (result.HospitalId == _hospital.HospitalId)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if doctor DoctorId is correct or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidateDoctor_DoctorId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                DoctorService.Setup(repo => repo.AddDoctor(_doctor)).ReturnsAsync(_doctor);
                var result = await _doctorServices.AddDoctor(_doctor);

                if (result.HospitalId == _doctor.DoctorId)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if client provided the DoctorId is correct or not while adding the review
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidateClientReview_DoctorId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientReviewService.Setup(repo => repo.AddClientReview(_clientReview)).ReturnsAsync(_clientReview);
                var result = await _clientReviewServices.AddClientReviews(_clientReview);

                if (result.DoctorId == _clientReview.DoctorId)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if client provided the clientId is correct or not while adding the review
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidateClientReview_ClientId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientReviewService.Setup(repo => repo.AddClientReview(_clientReview)).ReturnsAsync(_clientReview);
                var result = await _clientReviewServices.AddClientReviews(_clientReview);

                if (result.ClientId == _clientReview.ClientId)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if client provided the clientId is correct or not while adding the review
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidateAppointment_AppointmentId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                AppointmentService.Setup(repo => repo.AddAppointment(_appointment)).ReturnsAsync(_appointment);
                var result = await _appointmentServices.AddAppointment(_appointment);

                if (result.ClientId == _appointment.ClientId)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate if the appointment doctorId is correct or not while adding the review
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidateAppointment_DoctorId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                AppointmentService.Setup(repo => repo.AddAppointment(_appointment)).ReturnsAsync(_appointment);
                var result = await _appointmentServices.AddAppointment(_appointment);

                if (result.DoctorId == _appointment.DoctorId)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test_for_ValidEmail to test email id is valid or not
        /// </summary>
        ///  <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidEmail()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                bool isEmail = Regex.IsMatch(_client.Email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
                if (isEmail)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test_for_ValidateMobileNumber is used for test mobile number is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ValidateMobileNumber()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientService.Setup(repo => repo.AddClient(_client)).ReturnsAsync(_client);
                var result = await _clientServices.AddClient(_client);
                var actualLength = _client.PhoneNumber.ToString().Length;
                if (result.PhoneNumber.ToString().Length == actualLength)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate client name cannot be blanks.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Client_FirstName_NotEmpty()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientService.Setup(repo => repo.AddClient(_client)).ReturnsAsync(_client);
                var result = await _clientServices.AddClient(_client);
                var actualLength = _client.FirstName.Length;
                if (result.FirstName.Length == actualLength)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate Doctor name cannot be blanks.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Doctor_FirstName_NotEmpty()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                DoctorService.Setup(repo => repo.AddDoctor(_doctor)).ReturnsAsync(_doctor);
                var result = await _doctorServices.AddDoctor(_doctor);
                var actualLength = _doctor.FirstName.Length;
                if (result.FirstName.Length == actualLength)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate Hospital name cannot be blanks.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Hospital_FirstName_NotEmpty()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                HospitalService.Setup(repo => repo.AddHospital(_hospital)).ReturnsAsync(_hospital);
                var result = await _hospitalServices.AddHospital(_hospital);
                var actualLength = _doctor.FirstName.Length;
                if (result.HospitalName.Length == actualLength)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate Client review has DoctorRating cannot be blanks.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ClientReview_DoctorRating_NotEmpty()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientReviewService.Setup(repo => repo.AddClientReview(_clientReview)).ReturnsAsync(_clientReview);
                var result = await _clientReviewServices.AddClientReviews(_clientReview);
                var actualLength = _clientReview.Review.Length;
                if (result.Review.Length == actualLength)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate Client review has DoctorRating cannot be blanks.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_ClientReview_IsDoctorRecommended_NotEmpty()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                ClientReviewService.Setup(repo => repo.AddClientReview(_clientReview)).ReturnsAsync(_clientReview);
                var result = await _clientReviewServices.AddClientReviews(_clientReview);
                var actualValue = _clientReview.IsDoctorRecommended;
                if (result.IsDoctorRecommended == actualValue)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate Appointment has AppointmentStatus cannot be blanks.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Appointment_IsAppointmentStatus_NotEmpty()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                AppointmentService.Setup(repo => repo.AddAppointment(_appointment)).ReturnsAsync(_appointment);
                var result = await _appointmentServices.AddAppointment(_appointment);
                var actualValue = _appointment.Status;
                if (result.Status.Length == actualValue.Length)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //Asert//final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
        /// <summary>
        /// Test to validate Appointment has AppointmentStatus cannot be blanks.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_LoanProcesstrans_ManagerId_NotEmpty()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                AppointmentService.Setup(repo => repo.AddAppointment(_appointment)).ReturnsAsync(_appointment);
                var result = await _appointmentServices.AddAppointment(_appointment);
                var actualValue = _appointment.AppBookingChannelName;
                if (result.AppBookingChannelName.Length == actualValue.Length)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
    }
}