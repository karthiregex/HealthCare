﻿using HealthCare.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.DataLayer
{
    public class HealthCareDbContext : IdentityDbContext<UserMaster>
    {
        public HealthCareDbContext(DbContextOptions<HealthCareDbContext> options) : base(options)
        {

        }
        /// <summary>
        /// Seed and create DbSet for all healthcare classes
        /// </summary>
        public DbSet<ClsHospital> HospitalsDetails { get; set; }
        public DbSet<ClsClient> ClientDetails { get; set; }
        public DbSet<ClsDoctor> DoctorDetails { get; set; }
        public DbSet<ClsAppointment> AppointmentDetails { get; set; }
        public DbSet<ClsClientReview> ClientReviewDetails { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<ClsHospital>().HasKey(x => x.HospitalId);
            builder.Entity<ClsClient>().HasKey(x => x.ClientId);
            builder.Entity<ClsDoctor>().HasKey(x => x.DoctorId);
            builder.Entity<ClsAppointment>().HasKey(x => x.AppointmentId);
            builder.Entity<ClsClientReview>().HasKey(x => x.Id);
            base.OnModelCreating(builder);
        }
    }
}
