﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Services.Repository
{
    public interface IClientReviewRepository
    {
        Task<IEnumerable<ClsClientReview>> GetClientReviews();
        Task<ClsClientReview> GetClientReviewById(long clientId);
        Task<ClsClientReview> AddClientReview(ClsClientReview review);
        Task<ClsClientReview> UpdateClientReview(ClsClientReview review);
        Task<ClsClientReview> CancelClientReview(ClsClientReview review);
    }
}
