﻿using System;
using System.Threading.Tasks;
using HealthCare.BusinessLayer.Interfaces;
using HealthCare.BusinessLayer.Services.Repository;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Services
{
    public class DoctorServices : IDoctorServices
    {
        /// <summary>
        /// Creating instance/field of IDoctorRepository and injecting into DoctorServices Constructor
        /// </summary>
        private readonly IDoctorRepository _doctorRepository;
        public DoctorServices(IDoctorRepository doctorRepository)
        {
            _doctorRepository = doctorRepository;
        }

        /// <summary>
        /// Get all the doctor details 
        /// </summary>
        /// <param name="doctorId"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> GetDoctorDetails(long doctorId)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Method to get the doctor details by passing the DoctorId
        /// Admin can search the doctor information by using this method.
        /// </summary>
        /// <param name="doctorId"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> GetDoctorById(long doctorId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get the doctor details by the doctor name.
        /// client can search the doctor information by using this method.
        /// </summary>
        /// <param name="doctorName"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> GetDoctorByName(string doctorName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can add a new Doctor information by using this method.
        /// </summary>
        /// <param name="doctor"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> AddDoctor(ClsDoctor doctor)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can update the Doctor information's like address,city,state 
        /// </summary>
        /// <param name="doctor"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> UpdateDoctor(ClsDoctor doctor)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can delete the Doctor information if they don't want it.
        /// </summary>
        /// <param name="doctor"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> DeleteDoctor(ClsDoctor doctor)
        {
            throw new NotImplementedException();
        }
    }
}
