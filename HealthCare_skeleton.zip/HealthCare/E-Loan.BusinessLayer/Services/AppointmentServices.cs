﻿using System;
using System.Threading.Tasks;
using HealthCare.BusinessLayer.Interfaces;
using HealthCare.BusinessLayer.Services.Repository;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Services
{
    public class AppointmentServices : IAppointmentServices
    {
        /// <summary>
        /// Creating instance/field of IAppointmentRepository and injecting into AppointmentServices Constructor
        /// </summary>
        private readonly IAppointmentRepository _appointmentRepository;
        public AppointmentServices(IAppointmentRepository appointmentRepository)
        {
            _appointmentRepository = appointmentRepository;
        }

        /// <summary>
        /// Method to get the appointment details by passing the AppointmentId
        /// Admin can search the appointment information by using this method.
        /// </summary>
        /// <param name="appointmentId"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> GetAppointmentById(long appointmentId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get the appointment details by the appointment name.
        /// appointment can search the appointment information by using this method.
        /// </summary>
        /// <param name="clientName"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> GetAppointmentByClient(string clientName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get the appointment details by the appointment name.
        /// appointment can search the appointment information by using this method.
        /// </summary>
        /// <param name="doctorName"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> GetAppointmentByDoctor(string doctorName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can add a new Appointment information by using this method.
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> AddAppointment(ClsAppointment appointment)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can update the Appointment information's like address,city,state 
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> UpdateAppointment(ClsAppointment appointment)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can delete the Appointment information if they don't want it.
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> CancelAppointment(ClsAppointment appointment)
        {
            throw new NotImplementedException();
        }
    }
}
