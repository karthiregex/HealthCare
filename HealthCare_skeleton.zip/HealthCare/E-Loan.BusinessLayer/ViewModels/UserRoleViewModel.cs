﻿namespace HealthCare.BusinessLayer.ViewModels
{
    public class UserRoleViewModel
    {
        public string UserId { get; set; }
        public string Email { get; set; }
        //public bool IsSelected { get; set; }
    }
}
