﻿using System;
using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Interfaces
{
    public interface IAppointmentServices
    {
        Task<ClsAppointment> GetAppointmentById(long appId);
        Task<ClsAppointment> GetAppointmentByClient(String clientName);
        Task<ClsAppointment> GetAppointmentByDoctor(String doctorName);
        Task<ClsAppointment> AddAppointment(ClsAppointment appointment);
        Task<ClsAppointment> UpdateAppointment(ClsAppointment appointment);
        Task<ClsAppointment> CancelAppointment(ClsAppointment appointment);
    }
}
