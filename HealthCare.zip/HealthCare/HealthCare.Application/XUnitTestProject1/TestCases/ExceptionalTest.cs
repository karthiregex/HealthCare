﻿using System;
using System.IO;
using System.Threading.Tasks;
using HealthCare.BusinessLayer.Interfaces;
using HealthCare.BusinessLayer.Repository;
using HealthCare.BusinessLayer.Services;
using HealthCare.Entities;
using Moq;
using Xunit;

namespace HealthCare.Tests.TestCases
{
    public class ExceptionalTest
    {
        /// <summary>
        /// Creating reference Variable and Mocking repository class
        /// </summary>
        private readonly IAppointmentServices _appointmentServices;
        private readonly IClientReviewServices _clientReviewServices;
        private readonly IClientServices _clientServices;
        private readonly IDoctorServices _doctorServices;
        private readonly IHospitalServices _hospitalServices;

        public readonly Mock<IAppointmentRepository> AppointmentService = new Mock<IAppointmentRepository>();
        public readonly Mock<IClientReviewRepository> ClientReviewService = new Mock<IClientReviewRepository>();
        public readonly Mock<IClientRepository> ClientService = new Mock<IClientRepository>();
        public readonly Mock<IDoctorRepository> DoctorService = new Mock<IDoctorRepository>();
        public readonly Mock<IHospitalRepository> HospitalService = new Mock<IHospitalRepository>();

        private ClsAppointment _appointment;
        private ClsClient _client;
        private ClsClientReview _clientReview;
        private ClsDoctor _doctor;
        private ClsHospital _hospital;

        public ExceptionalTest()
        {
            ///// <summary>
            ///// Injecting service object into Test class constructor
            ///// </summary>
            _appointmentServices = new AppointmentServices(AppointmentService.Object);
            _clientReviewServices = new ClientReviewServices(ClientReviewService.Object);
            _clientServices = new ClientServices(ClientService.Object);
            _doctorServices = new DoctorServices(DoctorService.Object);
            _hospitalServices = new HospitalServices(HospitalService.Object);


            _appointment = new ClsAppointment()
            {
                ClientId = 1234,
                HospitalId = 552,
                DoctorId = 8563,
                AppBookingChannelName = "direct",
                AppointmentDate = DateTime.Now,
                AppointmentId = 112,
                StartTime = Convert.ToDateTime("05/29/2015 5:50 PM"),
                EndTime = Convert.ToDateTime("05/29/2015 6:50 PM"),
                Status = "Open"
            };

            _client = new ClsClient()
            {
                ClientId = 1234,
                Email = "Client1234@gmail.com",
                FirstName = "TestFirstName",
                LastName = "TestLastName",
                PhoneNumber = 8807712345
            };

            _clientReview = new ClsClientReview()
            {
                DoctorId = 8563,
                ClientId = 1234,
                DoctorRating = 5,
                Id = 333,
                IsDoctorRecommended = true,
                Review = "Very good Doctor",
                ReviewDate = DateTime.Now,
                WaitTimeRating = 5
            };
            _doctor = new ClsDoctor()
            {
                DoctorId = 8563,
                FirstName = "DocFirstName",
                LastName = "DocLastName",
                HospitalId = 552,
                PracticingFrom = Convert.ToDateTime("05/29/2015"),
                Specialization = "Cardiologist"
            };
            _hospital = new ClsHospital()
            {
                HospitalId = 552,
                City = "Mumbai",
                Country = "India",
                FirstConsultationFee = 500,
                FollowupConsultationFee = 300,
                HospitalName = "New Life Hospitals",
                PinCode = 400007,
                State = "Maharashtra",
                StreetAddress = "Main Road,Malabar Hill"
            };
        }

        /// <summary>
        /// Creating test output text file that store the result in boolean result
        /// </summary>
        static ExceptionalTest()
        {
            if (!File.Exists("../../../../output_exception_revised.txt"))
                try
                {
                    File.Create("../../../../output_exception_revised.txt").Dispose();
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            else
            {
                File.Delete("../../../../output_exception_revised.txt");
                File.Create("../../../../output_exception_revised.txt").Dispose();
            }
        }

        /// <summary>
        /// Test to validate if user pass the null object while add hospital, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Validate_InvalidHospital()
        {
            //Arrange
            bool res = false;
            _hospital = null;
            //Act
            HospitalService.Setup(repo => repo.AddHospital(_hospital)).ReturnsAsync(_hospital = null);
            var result = await _hospitalServices.AddHospital(_hospital);
            if (result == null)
            {
                res = true;
            }
            //Assert
            //final result displaying in text file
            await File.AppendAllTextAsync("../../../../output_exception_revised.txt",
                "Test_for_Validate_InvalidHospital=" + res + "\n");
            return res;
        }

        /// <summary>
        /// Test to validate if user pass the null object while add client, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Validate_InvalidClient()
        {
            //Arrange
            bool res = false;
            _client = null;
            //Act
            ClientService.Setup(repo => repo.AddClient(_client)).ReturnsAsync(_client = null);
            var result = await _clientServices.AddClient(_client);
            if (result == null)
            {
                res = true;
            }
            //Assert
            //final result displaying in text file
            await File.AppendAllTextAsync("../../../../output_exception_revised.txt",
                "Test_for_Validate_InvalidClient=" + res + "\n");
            return res;
        }

        /// <summary>
        /// Test to validate if user pass the null object while add Doctor, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Validate_InvalidDoctor()
        {
            //Arrange
            bool res = false;
            _doctor = null;
            //Act
            DoctorService.Setup(repo => repo.AddDoctor(_doctor)).ReturnsAsync(_doctor = null);
            var result = await _doctorServices.AddDoctor(_doctor);
            if (result == null)
            {
                res = true;
            }
            //Assert
            //final result displaying in text file
            await File.AppendAllTextAsync("../../../../output_exception_revised.txt",
                "Test_for_Validate_InvalidDoctor=" + res + "\n");
            return res;
        }

        /// <summary>
        /// Test to validate if user pass the null object while add Appointment, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Validate_InvalidAppointment()
        {
            //Arrange
            bool res = false;
            _appointment = null;
            //Act
            AppointmentService.Setup(repo => repo.AddAppointment(_appointment)).ReturnsAsync(_appointment = null);
            var result = await _appointmentServices.AddAppointment(_appointment);
            if (result == null)
            {
                res = true;
            }
            //Assert
            //final result displaying in text file
            await File.AppendAllTextAsync("../../../../output_exception_revised.txt",
                "Test_for_Validate_InvalidAppointment=" + res + "\n");
            return res;
        }

        /// <summary>
        /// Test to validate if user pass the null object while add ClientReview, return null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Test_for_Validate_InvalidClientReview()
        {
            //Arrange
            bool res = false;
            _clientReview = null;
            //Act
            ClientReviewService.Setup(repo => repo.AddClientReview(_clientReview)).ReturnsAsync(_clientReview = null);
            var result = await _clientReviewServices.AddClientReviews(_clientReview);
            if (result == null)
            {
                res = true;
            }
            //Assert
            //final result displaying in text file
            await File.AppendAllTextAsync("../../../../output_exception_revised.txt",
                "Test_for_Validate_InvalidClientReview=" + res + "\n");
            return res;
        }
    }
}
