﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.UI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        /// <summary>
        /// Creating the field of IClientServices and injecting in ClientController constructor
        /// </summary>
        private readonly IClientServices _clientServices;
        public AdminController(IClientServices clientServices)
        {
            _clientServices = clientServices;
        }

        /// <summary>
        /// //Admin action to provide appointment to the client
        /// </summary>
        /// <param name="model"></param>
        /// <param name="appointmentId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAppointMent")]
        public async Task<IActionResult> AddAppointMent([FromBody] ClsAppointment model, int appointmentId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Show/Get the list of appointments available based on the client search.
        /// Either client can pass the appointment name or the city name
        /// </summary>
        /// <param name="appointmentName"></param>
        /// <param name="city"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("SearchAppointment")]
        public async Task<IEnumerable<ClsAppointment>> SearchAppointment(string clientName, string doctorName)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can remove the appointment details if its not required
        /// </summary>
        /// <param name="appointmentId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("RemoveAppointment")]
        public async Task<bool> RemoveAppointment(int appointmentId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can edit the appointment details of an existing record
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateAppointment")]
        public async Task<bool> UpdateAppointment(ClsAppointment appointment)
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
