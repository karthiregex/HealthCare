﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.UI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HospitalController : ControllerBase
    {
        /// <summary>
        /// Creating the field of IClientServices and injecting in ClientController constructor
        /// </summary>
        private readonly IClientServices _clientServices;
        public HospitalController(IClientServices clientServices)
        {
            _clientServices = clientServices;
        }

        /// <summary>
        /// //Action to add a new hospital by admin
        /// </summary>
        /// <param name="model"></param>
        /// <param name="hospitalId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddHospital")]
        public async Task<IActionResult> AddHospital([FromBody] ClsHospital model, int hospitalId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Show/Get the list of hospitals available based on the client search.
        /// Either client can pass the hospital name or the city name
        /// </summary>
        /// <param name="hospitalName"></param>
        /// <param name="city"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("SearchHospital")]
        public async Task<IEnumerable<ClsHospital>> SearchHospital(string hospitalName, string city)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can remove the hospital details if its not required
        /// </summary>
        /// <param name="hospitalId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("RemoveHospital")]
        public async Task<bool> RemoveHospital(int hospitalId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can edit the hospital details of an existing record
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateHospital")]
        public async Task<bool> UpdateHospital(ClsHospital hospital)
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
