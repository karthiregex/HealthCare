﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.UI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        /// <summary>
        /// Creating the field of IClientServices and injecting in ClientController constructor
        /// </summary>
        private readonly IClientServices _clientServices;
        public ClientController(IClientServices clientServices)
        {
            _clientServices = clientServices;
        }

        /// <summary>
        /// //Action to add a new client , if they try logged the application first time
        /// </summary>
        /// <param name="model"></param>
        /// <param name="clientId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddClient")]
        public async Task<IActionResult> ClientRegister([FromBody] ClsClient model, int clientId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Show/Get the list of hospitals available based on the client search.
        /// Either client can pass the hospital name or the city name
        /// </summary>
        /// <param name="hospitalName"></param>
        /// <param name="city"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("SearchHospital")]
        public async Task<IEnumerable<ClsHospital>> SearchHospital(string hospitalName, string city)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Show/Get the list of Doctor available based on the client search.
        /// Either client can pass the Doctor name or the city name
        /// </summary>
        /// <param name="hospitalName"></param>
        /// <param name="city"></param>
        /// <returns>List of Doctors</returns>
        [HttpGet]
        [Route("SearchDoctor")]
        public async Task<IEnumerable<ClsDoctor>> SearchDoctor(string hospitalName, string city)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can raise or request a new appointment to a hospital and a doctor.
        /// Client need to pass the appointment details like hospital, doctor, startdate and end date
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("RequestAppointment")]
        public async Task<IEnumerable<ClsAppointment>> RequestAppointment([FromBody] ClsAppointment model)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can get\find all the appointments they raised.
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("MyAppointments")]
        public async Task<IEnumerable<ClsAppointment>> MyAppointments(int clientId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can cancel their existing appointment , need to pass the appointmentId to get the details and remove
        /// </summary>
        /// <param name="appintmentId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("CancelAppointments")]
        public async Task<bool> CancelAppointments(int appintmentId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can write their feedback about the hospital and the doctor he\she visited
        /// </summary>
        /// <param name="feedBack"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("AddDoctorFeedBack")]
        public async Task<bool> AddDoctorFeedBack([FromBody] ClsClientReview feedBack)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can get all the existing reviews about a doctor or the Hospital
        /// </summary>
        /// <param name="feedBack"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetReviews")]
        public async Task<IEnumerable<ClsClientReview>> GetReviews()
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
