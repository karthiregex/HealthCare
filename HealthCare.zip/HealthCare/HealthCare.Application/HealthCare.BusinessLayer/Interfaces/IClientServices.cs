﻿using System;
using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Interfaces
{
    public interface IClientServices
    {
        Task<ClsClient> GetClientById(long hospitalId);
        Task<ClsClient> GetClientByName(String hospitalName);
        Task<ClsClient> GetClientByCity(String cityName);
        Task<ClsClient> AddClient(ClsClient hospital);
        Task<ClsClient> UpdateClient(ClsClient hospital);
        Task<ClsClient> DeleteClient(ClsClient hospital);
    }
}
