﻿using System;
using System.Threading.Tasks;
using HealthCare.BusinessLayer.Interfaces;
using HealthCare.BusinessLayer.Repository;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Services
{
    public class ClientReviewServices : IClientReviewServices
    {
        /// <summary>
        /// Creating instance/field of IClientReviewRepository and injecting into ClientReviewServices Constructor
        /// </summary>
        private readonly IClientReviewRepository _clientReviewRepository;
        public ClientReviewServices(IClientReviewRepository clientReviewRepository)
        {
            _clientReviewRepository = clientReviewRepository;
        }

        /// <summary>
        /// get all the Client reviews 
        /// </summary>
        /// <returns></returns>
        public async Task<ClsClientReview> GetClientReviews()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// get all the Client reviews 
        /// </summary>
        /// <returns></returns>
        public async Task<ClsClientReview> GetClientReviewById(long reviewId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can add a new ClientReview information by using this method.
        /// </summary>
        /// <param name="clientReview"></param>
        /// <returns></returns>
        public async Task<ClsClientReview> AddClientReviews(ClsClientReview clientReview)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can update the ClientReview information's like address,city,state 
        /// </summary>
        /// <param name="clientReview"></param>
        /// <returns></returns>
        public async Task<ClsClientReview> UpdateClientReviews(ClsClientReview clientReview)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can delete the ClientReview information if they don't want it.
        /// </summary>
        /// <param name="clientReview"></param>
        /// <returns></returns>
        public async Task<ClsClientReview> CancelClientReviews(ClsClientReview clientReview)
        {
            throw new NotImplementedException();
        }
    }
}
