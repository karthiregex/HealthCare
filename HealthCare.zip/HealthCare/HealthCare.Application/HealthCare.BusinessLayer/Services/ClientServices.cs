﻿using System;
using System.Threading.Tasks;
using HealthCare.BusinessLayer.Interfaces;
using HealthCare.BusinessLayer.Repository;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Services
{
    public class ClientServices : IClientServices
    {
        /// <summary>
        /// Creating instance/field of IClientRepository and injecting into ClientServices Constructor
        /// </summary>
        private readonly IClientRepository _clientRepository;
        public ClientServices(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }

        /// <summary>
        /// Method to get the client details by passing the ClientId
        /// Admin can search the client information by using this method.
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        public async Task<ClsClient> GetClientById(long clientId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get the client details by the client name.
        /// client can search the client information by using this method.
        /// </summary>
        /// <param name="clientName"></param>
        /// <returns></returns>
        public async Task<ClsClient> GetClientByName(string clientName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get the client details by the client name.
        /// client can search the client information by using this method.
        /// </summary>
        /// <param name="cityName"></param>
        /// <returns></returns>
        public async Task<ClsClient> GetClientByCity(string cityName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can add a new Client information by using this method.
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        public async Task<ClsClient> AddClient(ClsClient client)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can update the Client information's like address,city,state 
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        public async Task<ClsClient> UpdateClient(ClsClient client)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can delete the Client information if they don't want it.
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        public async Task<ClsClient> DeleteClient(ClsClient client)
        {
            throw new NotImplementedException();
        }
    }
}
