﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.DataLayer;
using HealthCare.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.BusinessLayer.Repository
{
    class ClientReviewRepository : IClientReviewRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in ClientReviewRepository constructor
        /// </summary>
        private readonly HealthCareDbContext _healthCareContext;
        public ClientReviewRepository(HealthCareDbContext healthCareDbContext)
        {
            _healthCareContext = healthCareDbContext;
        }
        /// <summary>
        /// Show/Get all the ClientReviews details 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ClsClientReview>> GetClientReviews()
        {
            try
            {
                var result = await _healthCareContext.ClientReviewDetails
                    .OrderByDescending(x => x.Id).Take(10).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific ClientReviews information using the clientReviewId
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        public async Task<ClsClientReview> GetClientReviewById(long clientId)
        {
            try
            {
                var result = await _healthCareContext.ClientReviewDetails
                    .FirstOrDefaultAsync(h => h.ClientId.Equals(clientId));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

       
        /// <summary>
        /// Able to add a new clientReview information to the ClientReview table
        /// </summary>
        /// <param name="clientReview"></param>
        /// <returns></returns>
        public async Task<ClsClientReview> AddClientReview(ClsClientReview clientReview)
        {
            try
            {
                await _healthCareContext.ClientReviewDetails.AddAsync(clientReview);
                await _healthCareContext.SaveChangesAsync();
                return clientReview;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to Edit a specif clientReview information using the clientReview existing field
        /// </summary>
        /// <param name="clientReview"></param>
        /// <returns></returns>
        public Task<ClsClientReview> UpdateClientReview(ClsClientReview clientReview)
        {
            try
            {
                _healthCareContext.ClientReviewDetails.Update(clientReview);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(clientReview);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to delete a specif clientReview information using the clientReview existing field
        /// </summary>
        /// <param name="clientReview"></param>
        /// <returns></returns>
        public Task<ClsClientReview> CancelClientReview(ClsClientReview clientReview)
        {
            try
            {
                _healthCareContext.ClientReviewDetails.Remove(clientReview);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(clientReview);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
