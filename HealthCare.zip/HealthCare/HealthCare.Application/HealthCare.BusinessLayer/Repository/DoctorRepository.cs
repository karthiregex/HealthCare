﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.DataLayer;
using HealthCare.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.BusinessLayer.Repository
{
    public class DoctorRepository : IDoctorRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in DoctorRepository constructor
        /// </summary>
        private readonly HealthCareDbContext _healthCareContext;
        public DoctorRepository(HealthCareDbContext healthCareDbContext)
        {
            _healthCareContext = healthCareDbContext;
        }

        /// <summary>
        /// Show/Get all the Doctor details 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ClsDoctor>> GetDoctorDetails()
        {
            try
            {
                var result = await _healthCareContext.DoctorDetails
                    .OrderByDescending(x => x.HospitalId).Take(10).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Doctor information using the doctorId
        /// </summary>
        /// <param name="doctorId"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> GetDoctorById(long doctorId)
        {
            try
            {
                var result = await _healthCareContext.DoctorDetails
                    .FirstOrDefaultAsync(h => h.HospitalId.Equals(doctorId));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Doctor information using the doctorName
        /// </summary>
        /// <param name="doctorName"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> GetDoctorByName(string doctorName)
        {
            try
            {
                var result = await _healthCareContext.DoctorDetails
                    .FirstOrDefaultAsync(h => h.FirstName.Contains(doctorName));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to add a new doctor information to the Doctor table
        /// </summary>
        /// <param name="doctor"></param>
        /// <returns></returns>
        public async Task<ClsDoctor> AddDoctor(ClsDoctor doctor)
        {
            try
            {
                await _healthCareContext.DoctorDetails.AddAsync(doctor);
                await _healthCareContext.SaveChangesAsync();
                return doctor;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to Edit a specif doctor information using the doctor existing field
        /// </summary>
        /// <param name="doctor"></param>
        /// <returns></returns>
        public Task<ClsDoctor> UpdateDoctor(ClsDoctor doctor)
        {
            try
            {
                _healthCareContext.DoctorDetails.Update(doctor);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(doctor);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to delete a specif doctor information using the doctor existing field
        /// </summary>
        /// <param name="doctor"></param>
        /// <returns></returns>
        public Task<ClsDoctor> DeleteDoctor(ClsDoctor doctor)
        {
            try
            {
                _healthCareContext.DoctorDetails.Remove(doctor);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(doctor);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
