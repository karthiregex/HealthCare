﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Repository
{
    public interface IAppointmentRepository
    {
        Task<IEnumerable<ClsAppointment>> GetAppointmentDetails();
        Task<ClsAppointment> GetAppointmentById(long appId);
        Task<ClsAppointment> GetAppointmentByClient(long clientName);
        Task<ClsAppointment> GetAppointmentByDoctor(long doctorName);
        Task<ClsAppointment> AddAppointment(ClsAppointment appointment);
        Task<ClsAppointment> UpdateAppointment(ClsAppointment appointment);
        Task<ClsAppointment> CancelAppointment(ClsAppointment appointment);
    }
}
