﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Repository
{
    public interface IClientRepository
    {
        Task<IEnumerable<ClsClient>> GetClientDetails();
        Task<ClsClient> GetClientById(long clientId);
        Task<IEnumerable<ClsClient>> GetClientByName(String clientName);
        Task<ClsClient> AddClient(ClsClient client);
        Task<ClsClient> UpdateClient(ClsClient client);
        Task<ClsClient> DeleteClient(ClsClient client);
    }
}
