﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.DataLayer;
using HealthCare.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.BusinessLayer.Repository
{
    public class ClientRepository : IClientRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in ClientRepository constructor
        /// </summary>
        private readonly HealthCareDbContext _healthCareContext;
        public ClientRepository(HealthCareDbContext healthCareDbContext)
        {
            _healthCareContext = healthCareDbContext;
        }

        /// <summary>
        /// Show/Get all the Clients details 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ClsClient>> GetClientDetails()
        {
            try
            {
                var result = await _healthCareContext.ClientDetails
                    .OrderByDescending(x => x.ClientId).Take(10).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Client information using the clientId
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        public async Task<ClsClient> GetClientById(long clientId)
        {
            try
            {
                var result = await _healthCareContext.ClientDetails
                    .FirstOrDefaultAsync(h => h.ClientId.Equals(clientId));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Client information using the clientName
        /// </summary>
        /// <param name="clientName"></param>
        /// <returns></returns>
        public async Task<IEnumerable<ClsClient>> GetClientByName(string clientName)
        {
            try
            {
                var result = await _healthCareContext.ClientDetails
                    .OrderByDescending(h => h.FirstName.Contains(clientName)).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to add a new client information to the Client table
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        public async Task<ClsClient> AddClient(ClsClient client)
        {
            try
            {
                await _healthCareContext.ClientDetails.AddAsync(client);
                await _healthCareContext.SaveChangesAsync();
                return client;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to Edit a specif client information using the client existing field
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        public Task<ClsClient> UpdateClient(ClsClient client)
        {
            try
            {
                _healthCareContext.ClientDetails.Update(client);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(client);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to delete a specif client information using the client existing field
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        public Task<ClsClient> DeleteClient(ClsClient client)
        {
            try
            {
                _healthCareContext.ClientDetails.Remove(client);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(client);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
