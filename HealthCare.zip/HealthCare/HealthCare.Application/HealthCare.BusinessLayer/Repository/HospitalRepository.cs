﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.DataLayer;
using HealthCare.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.BusinessLayer.Repository
{
    class HospitalRepository : IHospitalRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in HospitalRepository constructor
        /// </summary>
        private readonly HealthCareDbContext _healthCareContext;
        public HospitalRepository(HealthCareDbContext healthCareDbContext)
        {
            _healthCareContext = healthCareDbContext;
        }
        /// <summary>
        /// Show/Get all the Hospitals details 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ClsHospital>> GetHospitalDetails()
        {
            try
            {
                var result = await _healthCareContext.HospitalsDetails
                    .OrderByDescending(x => x.HospitalId).Take(10).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Hospitals information using the hospitalId
        /// </summary>
        /// <param name="hospitalId"></param>
        /// <returns></returns>
        public async Task<ClsHospital> GetHospitalById(long hospitalId)
        {
            try
            {
                var result = await _healthCareContext.HospitalsDetails
                    .FirstOrDefaultAsync(h => h.HospitalId.Equals(hospitalId));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Hospitals information using the hospitalName
        /// </summary>
        /// <param name="hospitalName"></param>
        /// <returns></returns>
        public async Task<ClsHospital> GetHospitalByName(string hospitalName)
        {
            try
            {
                var result = await _healthCareContext.HospitalsDetails
                    .FirstOrDefaultAsync(h => h.HospitalName.Contains(hospitalName));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to add a new hospital information to the Hospital table
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        public async Task<ClsHospital> AddHospital(ClsHospital hospital)
        {
            try
            {
                await _healthCareContext.HospitalsDetails.AddAsync(hospital);
                await _healthCareContext.SaveChangesAsync();
                return hospital;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to Edit a specif hospital information using the hospital existing field
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        public Task<ClsHospital> UpdateHospital(ClsHospital hospital)
        {
            try
            {
                _healthCareContext.HospitalsDetails.Update(hospital);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(hospital);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to delete a specif hospital information using the hospital existing field
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        public Task<ClsHospital> DeleteHospital(ClsHospital hospital)
        {
            try
            {
                _healthCareContext.HospitalsDetails.Remove(hospital);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(hospital);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
