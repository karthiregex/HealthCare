﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.DataLayer;
using HealthCare.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.BusinessLayer.Repository
{
    public class AppointmentRepository : IAppointmentRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in AppointmentRepository constructor
        /// </summary>
        private readonly HealthCareDbContext _healthCareContext;
        public AppointmentRepository(HealthCareDbContext healthCareDbContext)
        {
            _healthCareContext = healthCareDbContext;
        }

        /// <summary>
        /// Show/Get all the Appointment details 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ClsAppointment>> GetAppointmentDetails()
        {
            try
            {
                var result = await _healthCareContext.AppointmentDetails
                    .OrderByDescending(x => x.AppointmentId).Take(10).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Appointment information using the appointmentId
        /// </summary>
        /// <param name="appointmentId"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> GetAppointmentById(long appointmentId)
        {
            try
            {
                var result = await _healthCareContext.AppointmentDetails
                    .FirstOrDefaultAsync(h => h.AppointmentId.Equals(appointmentId));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Appointment information using the client details
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> GetAppointmentByClient(long clientId)
        {
            try
            {
                var result = await _healthCareContext.AppointmentDetails
                    .FirstOrDefaultAsync(h => h.ClientId.Equals(clientId));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get specific Appointment information using the doctor details
        /// </summary>
        /// <param name="doctorId"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> GetAppointmentByDoctor(long doctorId)
        {
            try
            {
                var result = await _healthCareContext.AppointmentDetails
                    .FirstOrDefaultAsync(h => h.ClientId.Equals(doctorId));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to add a new appointment information to the Appointment table
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<ClsAppointment> AddAppointment(ClsAppointment appointment)
        {
            try
            {
                await _healthCareContext.AppointmentDetails.AddAsync(appointment);
                await _healthCareContext.SaveChangesAsync();
                return appointment;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to Edit a specif appointment information using the appointment existing field
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public Task<ClsAppointment> UpdateAppointment(ClsAppointment appointment)
        {
            try
            {
                _healthCareContext.AppointmentDetails.Update(appointment);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(appointment);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to delete a specif appointment information using the appointment existing field
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public Task<ClsAppointment> CancelAppointment(ClsAppointment appointment)
        {
            try
            {
                _healthCareContext.AppointmentDetails.Remove(appointment);
                _healthCareContext.SaveChangesAsync();
                return Task.FromResult(appointment);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


    }
}
