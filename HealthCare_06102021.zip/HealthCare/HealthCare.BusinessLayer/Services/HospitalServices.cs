﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.BusinessLayer.Interfaces;
using HealthCare.BusinessLayer.Services.Repository;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Services
{
    public class HospitalServices : IHospitalServices
    {
        /// <summary>
        /// Creating instance/field of IHospitalRepository and injecting into HospitalServices Constructor
        /// </summary>
        private readonly IHospitalRepository _hospitalRepository;
        public HospitalServices(IHospitalRepository hospitalRepository)
        {
            _hospitalRepository = hospitalRepository;
        }

        /// <summary>
        /// Method to get the hospital details by passing the HospitalId
        /// Admin can search the hospital information by using this method.
        /// </summary>
        /// <param name="hospitalId"></param>
        /// <returns></returns>
        public async Task<ClsHospital> GetHospitalById(long hospitalId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get the hospital details by the hospital name.
        /// client can search the hospital information by using this method.
        /// </summary>
        /// <param name="hospitalName"></param>
        /// <returns></returns>
        public async Task<ClsHospital> GetHospitalByName(string hospitalName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get the hospital details by the hospital name.
        /// client can search the hospital information by using this method.
        /// </summary>
        /// <param name="city"></param>
        /// <returns></returns>
        public async Task<IEnumerable<ClsHospital>> GetHospitalByCity(string city)
        {
            Task<IEnumerable<ClsHospital>> result = await Task.FromResult(_hospitalRepository.GetHospitalByCity(city));
            return await result;
        }

        /// <summary>
        /// Admin can add a new Hospital information by using this method.
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        public async Task<ClsHospital> AddHospital(ClsHospital hospital)
        {
            var result = _hospitalRepository.AddHospital(hospital);
            return await result;
        }

        /// <summary>
        /// Admin can update the Hospital information's like address,city,state 
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        public async Task<ClsHospital> UpdateHospital(ClsHospital hospital)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can delete the Hospital information if they don't want it.
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        public async Task<ClsHospital> DeleteHospital(ClsHospital hospital)
        {
            throw new NotImplementedException();
        }
    }
}
