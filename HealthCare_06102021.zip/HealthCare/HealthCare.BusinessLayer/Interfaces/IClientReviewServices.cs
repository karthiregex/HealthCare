﻿using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Interfaces
{
    public interface IClientReviewServices
    {
        Task<ClsClientReview> GetClientReviewById(long reviewId);
        Task<ClsClientReview> GetClientReviews();
        Task<ClsClientReview> AddClientReviews(ClsClientReview review);
        Task<ClsClientReview> UpdateClientReviews(ClsClientReview review);
        Task<ClsClientReview> CancelClientReviews(ClsClientReview review);
    }
}
