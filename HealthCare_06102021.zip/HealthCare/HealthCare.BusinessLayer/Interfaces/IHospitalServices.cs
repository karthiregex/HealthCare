﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.Entities;

namespace HealthCare.BusinessLayer.Interfaces
{
    public interface IHospitalServices
    {
        Task<ClsHospital> GetHospitalById(long hospitalId);
        Task<ClsHospital> GetHospitalByName(string hospitalName);
        Task<IEnumerable<ClsHospital>> GetHospitalByCity(string city);
        Task<ClsHospital> AddHospital(ClsHospital hospital);
        Task<ClsHospital> UpdateHospital(ClsHospital hospital);
        Task<ClsHospital> DeleteHospital(ClsHospital hospital);
    }
}
