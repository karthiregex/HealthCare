﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HealthCare.Entities
{
    public class ClsAppointment
    {
        [Key]
        public int AppointmentId { get; set; }
        [Required]
        [Display(Name = "ClientId")]
        public int ClientId { get; set; }
        [Required]
        [Display(Name = "DoctorId")]
        public int DoctorId { get; set; }
        [Required]
        [Display(Name = "HospitalId")]
        public int HospitalId { get; set; }
        [Required]
        [Display(Name = "StartTime")]
        public DateTime StartTime { get; set; }
        [Required]
        [Display(Name = "EndTime")]
        public DateTime EndTime { get; set; }
        [Required]
        [Display(Name = "AppointmentDate")]
        public DateTime AppointmentDate { get; set; }
        [Required]
        [Display(Name = "AppointmentStatus")]
        public string Status { get; set; }
        [Required]
        [Display(Name = "AppBookingChannelName")]
        public string AppBookingChannelName { get; set; }
    }
}
