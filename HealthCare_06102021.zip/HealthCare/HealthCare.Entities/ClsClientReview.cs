﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HealthCare.Entities
{
    public class ClsClientReview
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Display(Name = "ClientId")]
        public int ClientId { get; set; }
        [Required]
        [Display(Name = "DoctorId")]
        public int DoctorId { get; set; }
        [Required]
        [Display(Name = "WaitTimeRating")]
        public int WaitTimeRating { get; set; }
        [Required]
        [Display(Name = "DoctorRating")]
        public int DoctorRating { get; set; }
        [Required]
        [Display(Name = "Review")]
        public string Review { get; set; }
        [Required]
        [Display(Name = "IsDoctorRecommended")]
        public bool IsDoctorRecommended { get; set; }
        [Required]
        [Display(Name = "ReviewDate")]
        public DateTime ReviewDate { get; set; }

    }
}
