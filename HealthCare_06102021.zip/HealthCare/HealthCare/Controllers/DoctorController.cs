﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        /// <summary>
        /// Creating the field of IClientServices and injecting in ClientController constructor.
        /// Here if you try to add new doctor why you are using doctor Id and passing in argument
        /// </summary>
        private readonly IDoctorServices _clientServices;
        public DoctorController(IDoctorServices clientServices)
        {
            _clientServices = clientServices;
        }

        /// <summary>
        /// Action to add a new doctor by admin, needs to pass the Doctor model as parameter
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        ///
        [HttpPost]
        [Route("AddDoctor")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> AddDoctor([FromBody] ClsDoctor model)
        {
            //do code here
            var result = _clientServices.AddDoctor(model);
            return await result;
        }

        /// <summary>
        /// Show/Get the list of doctors available with the given name based on the client search.
        /// </summary>
        /// <param name="doctorName"></param>
        /// <returns></returns>
        ///
        [HttpGet]
        [Route("DoctorSearch/{doctorName}")]
        public async Task<IEnumerable<ClsDoctor>> DoctorSearch(string doctorName)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Admin can remove the doctor details if its not required.
        /// </summary>
        /// <param name="doctorId"></param>
        /// <returns></returns>
        ///
        [HttpDelete]
        [Route("RemoveDoctor/{doctorId}")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> DeleteDoctor(int doctorId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can edit the doctor details of an existing record
        /// </summary>
        /// <param name="doctor"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateDoctor")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> EditDoctor(ClsDoctor doctor)
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
