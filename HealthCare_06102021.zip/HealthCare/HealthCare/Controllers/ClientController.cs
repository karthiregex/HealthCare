﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.Entities;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        /// <summary>
        /// Creating the field of IClientServices and injecting in ClientController constructor
        /// </summary>
        private readonly IClientServices _clientServices;
        private readonly IHospitalServices _hospitalServices;
        private readonly IDoctorServices _doctorServices;
        public ClientController(IClientServices clientServices, IHospitalServices hospitalService, IDoctorServices doctorServices)
        {
            _clientServices = clientServices;
            _hospitalServices = hospitalService;
            _doctorServices = doctorServices;
        }

        /// <summary>
        /// //Action to add a new client , if the user trying to login to the application for the first time
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddClient")]
        public async Task<ClsClient> ClientRegister([FromBody] ClsClient model)
        {
            //do code here
            var result = _clientServices.AddClient(model);
            return await result;
        }

        /// <summary>
        /// Show/Get the hospital details based on the user input .
        /// </summary>
        /// <param name="hospitalName"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("SearchHospital/{hospitalName}")]
        public async Task<ClsHospital> SearchHospital(string hospitalName)
        {
            Task<ClsHospital> result = null;
            if (!string.IsNullOrEmpty(hospitalName))
            {
                result = _hospitalServices.GetHospitalByName(hospitalName);
            }
            if (result != null) return await result;
            return null;
        }


        /// <summary>
        /// Show/Get the hospitals in the city based on the user input .
        /// </summary>
        /// <param name="city"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("HospitalsInCity/{city}")]
        public async Task<IEnumerable<ClsHospital>> SearchHospitalByCity(string city)
        {
            Task<IEnumerable<ClsHospital>> result = null;
            if (!string.IsNullOrEmpty(city))
            {
                result = _hospitalServices.GetHospitalByCity(city);
            }

            if (result != null) return await result;
            return null;
        }

        /// <summary>
        /// Show/Get the list of Doctor available based on the client search.
        /// </summary>
        /// <param name="doctorName"></param>
        /// <returns>List of Doctors</returns>
        ///
        [HttpGet]
        [Route("ClientSearchDoctor/{doctorName}")]
        public async Task<IEnumerable<ClsDoctor>> SearchDoctor(string doctorName)
        {
            Task<IEnumerable<ClsDoctor>> result = null;
            if (!string.IsNullOrEmpty(doctorName))
            {
                result = _doctorServices.GetDoctorByName(doctorName);
            }

            if (result != null) return await result;
            return null;

            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can raise or request a new appointment to a hospital and a doctor.
        /// Client need to pass the appointment details like hospital, doctor, Start date and end date
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Returns the Appointment id</returns>
        /// 
        [HttpPost]
        [Route("RequestAppointment")]
        public async Task<int> RequestAppointment([FromBody] ClsAppointment model)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can get\find all the appointments they raised.
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("MyAppointments/{clientId}")]
        public async Task<IEnumerable<ClsAppointment>> MyAppointments(int clientId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can cancel their existing appointment , need to pass the appointmentId to get the details and remove
        /// </summary>
        /// <param name="appintmentId"></param>
        /// <returns></returns>
        /// 
        [HttpGet]
        [Route("CancelAppointments/{appintmentId}")]
        public async Task<bool> CancelAppointments(int appintmentId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can write their feedback about the hospital and the doctor he\she visited
        /// </summary>
        /// <param name="feedBack"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddDoctorFeedBack")]
        public async Task<bool> AddDoctorFeedBack([FromBody] ClsClientReview feedBack)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Client can get all the existing reviews about a doctor or the Hospital
        /// </summary>
        /// <param name="feedBack"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetReviews")]
        public async Task<IEnumerable<ClsClientReview>> GetReviews()
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
