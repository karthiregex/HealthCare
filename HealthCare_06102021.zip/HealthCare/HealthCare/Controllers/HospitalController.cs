﻿using HealthCare.BusinessLayer.Interfaces;
using HealthCare.Entities;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace HealthCare.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HospitalController : ControllerBase
    {
        /// <summary>
        /// Creating the field of IClientServices and injecting in ClientController constructor
        /// </summary>
        private readonly IHospitalServices _hospitalServices;
        public HospitalController(IHospitalServices hospitalServices)
        {
            _hospitalServices = hospitalServices;
        }

        /// <summary>
        /// Action to add a new hospital by admin
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        /// 

        [HttpPost]
        [Route("AddHospital/{hospitalId}")]
        [Authorize(Roles = "Admin")]
        public async Task<ClsHospital> AddHospital([FromBody] ClsHospital model)
        {
            var result = _hospitalServices.AddHospital(model);
            return await result;
        }

        /// <summary>
        /// Show/Get the hospital details based on the client search.
        /// </summary>
        /// <param name="hospitalName"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("SearchHospital/{hospitalName}")]
        public async Task<ClsHospital> SearchHospital(string hospitalName)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Show/Get the list of hospitals available in the city based on the client search.
        /// </summary>
        /// <param name="city"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("SearchHospitalinCity/{city}")]
        public async Task<IEnumerable<ClsHospital>> SearchHospitalinCity(string city)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can remove a hospital detail if its not required
        /// </summary>
        /// <param name="hospitalId"></param>
        /// <returns></returns>
        ///
        [HttpDelete]
        [Route("RemoveHospital/{hospitalId}")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> RemoveHospital(int hospitalId)
        {
            //do code here
            throw new NotImplementedException();
        }

        /// <summary>
        /// Admin can edit the hospital details of an existing record
        /// </summary>
        /// <param name="hospital"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateHospital")]
        [Authorize(Roles = "Admin")]
        public async Task<bool> UpdateHospital(ClsHospital hospital)
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
